## Ryan Elmore
## Date:
## Prelims

## Set working directory
setwd(paste(wd, "src/", sep = ""))

## Load project-specific functions
source(paste(wd, "src/functions.R", sep=""))

## Load libraries
library(ggplot2)

## Load data
## data.str <- paste(wd, "data/some_data_file.dat", sep = "")
