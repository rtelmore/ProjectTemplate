## Ryan Elmore
## Date:
## Scratch pad 


